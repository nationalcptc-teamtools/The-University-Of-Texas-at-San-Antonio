
- **Nmap service/version + SSH scripts**  
`nmap -p 22 -sV --script=ssh-hostkey,ssh2-enum-algos,ssh-auth-methods,vulners <target>` 

- **Banner / verbose handshake**  
`ssh -vvv user@<target>`

- **Username enumeration**
`ssh -o PreferredAuthentications=none -o ConnectTimeout=5 <user>@<target>`