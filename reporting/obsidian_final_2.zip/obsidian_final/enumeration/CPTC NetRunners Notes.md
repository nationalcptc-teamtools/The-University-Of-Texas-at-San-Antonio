This is our notes vault, where we will be holding all of our knowledge during the testing. 

Ensure to copy over the ENUMERATION checklists per identified hosts to make sure that we have adequate coverage on things to enumerate for.