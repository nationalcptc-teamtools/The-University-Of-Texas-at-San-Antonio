
Things to check:
- Unused or legacy protocols (e.g., Telnet, SMBv1, RDP without NLA, Modbus/TCP without encryption)
- Firewall rules between IT and OT should block excessive inbound/outbound ports and only allow required protocols
- Default vendor credentials on PLCs, HMIs, or OT servers
- Modbus No Firewall  
- Telnet PLC-based interface 
- Unauthenticated VNC Access 
- Unauthenticated PLC Modbus 
- Custom PLC with unauthenticated debug interfaces 
- Improper Network Segmentation for OT 
- Default Credentials on HMI (SCADABR) 
- Unauthenticated RCE via File Upload on SCADABR  (or other software)
- PLCs and controllers should have firmware signed and updated (software version checks)

## Tools

- [https://sourceforge.net/projects/qmodmaster/](https://sourceforge.net/projects/qmodmaster/ "https://sourceforge.net/projects/qmodmaster/"),
- [https://github.com/ExplorerOL/QModbusExplorer](https://github.com/ExplorerOL/QModbusExplorer "https://github.com/ExplorerOL/QModbusExplorer")

