
# X.X.X.X (IP)

## FINDING 1 

Endpoint:
Version number:
CVE:
**Vulnerability Explanation:** 
Timestamp:
**Steps to reproduce the attack:**
**Proof of Concept Screenshots:

## FINDING 2 


Endpoint:
Version number:
CVE:
**Vulnerability Explanation:** 
**Steps to reproduce the attack:**
**Proof of Concept Screenshots:


# X.X.X.X (IP)

## FINDING 1 

Endpoint:
Version number:
CVE:
**Vulnerability Explanation:** 
**Steps to reproduce the attack:**
**Proof of Concept Screenshots:

## FINDING 2 


Endpoint:
Version number:
CVE:
**Vulnerability Explanation:** 
**Steps to reproduce the attack:**
**Proof of Concept Screenshots:


