
- **NMAP Port & version discovery (save results)**  - LOOK FOR CVEs with version number
`nmap -p 21 -sV --version-intensity 9 -oA results/<target>_ftp <target>`

- Banner grabbing - LOOK FOR CVEs with version number
`telnet <target> 21`
`nc -v <target> 21`

- Default credentials & Brute-force easy passwords 
`hydra -l <user> -P /path/wordlist.txt ftp://<target>`

- Anonymous login (`anonymous`)
`ftp -nv <target>`  and `anonymous:anonymous`

- Explore directories
`ftp -nv <target>`

- Try to put a test file - if there is a web service, check if it has the same path as FTP as it might feed from there.