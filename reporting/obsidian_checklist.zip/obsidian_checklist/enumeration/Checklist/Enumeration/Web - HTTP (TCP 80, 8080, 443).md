
### ALWAYS TRY TO BROWSE AND CHECK EVERY WEB PORT THAT IS EXPOSED MANUALLY.

- NMAP script scan
`nmap -p 80,443 -sV --script http-title,http-headers,http-enum <target>`

**Web server & app fingerprinting**  
`whatweb http://<target>`  
`nikto -host http://<target>`  

If Wordpress: 
`wpscan --url https://<target> --enumerate vp,vt,u --disable-tls-checks` 
`nikto -host http://<target> -Tuning 1,2`

- **Check robots / sitemap / common files**  
`curl -fsS http://<target>/robots.txt`  
`curl -fsS http://<target>/sitemap.xml`

- **Directory enumeration `gobuster`**
`gobuster dir -u http://<target> -w /path/wordlist.txt -x php,html,txt,asp -t 30`'

- **VHost / virtual host discovery**  
`gobuster vhost -u http://<target> -w /path/to/vhosts.txt`  
`curl --header "Host: some.vhost.example" http://<target>`

* **SSL/TLS inspection**
`nmap --script ssl-enum-ciphers -p 443 <target>`  
`openssl s_client -connect <target>:443 -servername <host>`

- CVE Lookup with version
`nmap -sV --script=vuln,vulners -p 80,443 <target>`  
`searchsploit "Apache 2.4.29"`  
`searchsploit "nginx 1.14.0"`