
Things to check:
- Entra ID User should have MFA,
- entra ID user should not be inactive for more than 90d,
- application secrets should be rotated every 90d,
- third party service account with high privs,
- admin account inactive for 90d,
- admin / service account with active access keys unrotated in past year
- - guest accounts with write permissions on azure resources should be removed,
- role based access control should be on azure key vault services,
- Microsoft defender should be enabled,
- check for excessive high inbound ports,
- key vaults should have soft delete enabled,
- subscriptions should not have more than 3 owners