
### Initial Access - SSH

**Vulnerability Explanation:** 
**Vulnerability Fix:** 
**Severity:** 
**Steps to reproduce the attack:**
**Proof of Concept Code**:

